# Student Marks Card Application

## Overview
A React-based Student Marks Card application demonstrating parent-child component communication using **props**.

## Project Structure

```
📁 Student Marks Card/
├── App.jsx              # Parent component - stores student data
├── StudentCard.jsx      # Child component - displays student information
├── index.js             # React entry point
├── index.html           # HTML template
├── package.json         # Project dependencies
└── README.md           # Documentation (this file)
```

## Components

### App.jsx (Parent Component)
- **Purpose**: Main container that stores all student data
- **Data Structure**: Array of student objects with:
  - `name`: Student's full name
  - `rollNumber`: Student's roll number
  - `marks`: Array of subject marks (5 subjects)
- **Functionality**:
  - Stores data for multiple students
  - Passes data to `StudentCard` using props
  - Maps through students array to reuse `StudentCard` component

### StudentCard.jsx (Child Component)
- **Purpose**: Displays individual student information
- **Props Received**:
  - `name`: String - Student's name
  - `rollNumber`: String - Student's identification number
  - `marks`: Array - Subject-wise marks

#### Features:
1. **Data Display**:
   - Student name and roll number
   - Subject-wise marks (out of 100)

2. **Calculations** (Bonus Challenge):
   - **Total Marks**: Sum of all subject marks
   - **Average**: Percentage average across subjects
   - **Grade**: Automatic grading based on average:
     - A: 90-100%
     - B: 80-89%
     - C: 70-79%
     - D: 60-69%
     - F: Below 60%

3. **Visual Design**:
   - Color-coded grade display
   - Responsive card layout
   - Professional styling with shadows and borders
   - Grade-specific colors (Green for A, Blue for B, etc.)

## Props Flow Diagram

```
┌─────────────────────────────────┐
│         App (Parent)            │
│                                 │
│ students = [                    │
│   { name, rollNumber, marks },  │
│   { name, rollNumber, marks },  │
│   ...                           │
│ ]                               │
└────────────┬────────────────────┘
             │
             │ Pass via props
             ▼
    ┌────────────────────┐
    │  StudentCard       │
    │  (Child)           │
    │                    │
    │  Props:            │
    │  - name            │
    │  - rollNumber      │
    │  - marks[]         │
    │                    │
    │  Display & Calculate
    │  - Total           │
    │  - Average         │
    │  - Grade           │
    └────────────────────┘
```

## Sample Data

The application includes 5 sample students:

1. **Priya Singh** (CS001) - Marks: [92, 88, 95, 89, 91]
2. **Arjun Patel** (CS002) - Marks: [85, 78, 82, 88, 80]
3. **Neha Sharma** (CS003) - Marks: [78, 75, 72, 80, 76]
4. **Rohit Kumar** (CS004) - Marks: [95, 93, 96, 94, 98]
5. **Anjali Verma** (CS005) - Marks: [88, 92, 90, 87, 89]

## Getting Started

### Installation
```bash
npm install
```

### Run Development Server
```bash
npm start
```
Opens http://localhost:3000 in your browser

### Build for Production
```bash
npm run build
```

## Key Concepts Demonstrated

✅ **Props Usage**: Data passed from parent to child component
✅ **Component Reusability**: Single `StudentCard` component used for multiple students
✅ **Data Flow**: Clear parent-child data flow visualization
✅ **Array Mapping**: Rendering multiple components using `.map()`
✅ **Calculations**: Performing calculations in child component (total, average, grade)
✅ **Conditional Logic**: Grade determination based on average percentage
✅ **Styling**: Inline CSS and responsive grid layout

## Output Examples

Each StudentCard displays:
- Student name in header
- Roll number
- Subject-wise marks
- **Total Marks**: Sum of all marks
- **Average**: Percentage calculated from total
- **Grade**: Color-coded grade (A/B/C/D/F)

## Bonus Challenge Implementation

✅ **Total Calculation**: `marks.reduce((sum, mark) => sum + mark, 0)`
✅ **Grade Calculation**: Based on average percentage
✅ **Component Reusability**: Same component renders for 5+ students

## Technologies Used

- **React 18.2**: UI library
- **CSS-in-JS**: Inline styling for component customization
- **JavaScript ES6**: Modern JavaScript features

## Learning Outcomes

After completing this project, you'll understand:
- How to create parent and child components
- How to pass data using props
- How to render lists of components
- How to perform calculations in child components
- How to structure reusable components
- Component lifecycle and data flow in React
