import React from 'react';
import StudentCard from './StudentCard';

const App = () => {
  // Store student details in the parent component
  const students = [
    {
      id: 1,
      name: 'Priya Singh',
      rollNumber: 'CS001',
      marks: [92, 88, 95, 89, 91]
    },
    {
      id: 2,
      name: 'Arjun Patel',
      rollNumber: 'CS002',
      marks: [85, 78, 82, 88, 80]
    },
    {
      id: 3,
      name: 'Neha Sharma',
      rollNumber: 'CS003',
      marks: [78, 75, 72, 80, 76]
    },
    {
      id: 4,
      name: 'Rohit Kumar',
      rollNumber: 'CS004',
      marks: [95, 93, 96, 94, 98]
    },
    {
      id: 5,
      name: 'Anjali Verma',
      rollNumber: 'CS005',
      marks: [88, 92, 90, 87, 89]
    },
  ];

  return (
    <div style={styles.appContainer}>
      <header style={styles.header}>
        <h1 style={styles.title}>Student Marks Card System</h1>
        <p style={styles.subtitle}>Managing student performance data</p>
      </header>

      <div style={styles.statsContainer}>
        <div style={styles.statCard}>
          <span style={styles.statValue}>{students.length}</span>
          <span style={styles.statLabel}>Total Students</span>
        </div>
      </div>

      <div style={styles.cardsContainer}>
        {/* Reusable StudentCard component for multiple students */}
        {students.map((student) => (
          <StudentCard
            key={student.id}
            name={student.name}
            rollNumber={student.rollNumber}
            marks={student.marks}
          />
        ))}
      </div>

      <footer style={styles.footer}>
        <p>© 2026 Student Marks Card System | Props-based Data Flow Demo</p>
      </footer>
    </div>
  );
};

const styles = {
  appContainer: {
    minHeight: '100vh',
    backgroundColor: '#ecf0f1',
    fontFamily: 'Arial, sans-serif',
  },
  header: {
    backgroundColor: '#2c3e50',
    color: 'white',
    padding: '30px 20px',
    textAlign: 'center',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  },
  title: {
    margin: '0 0 10px 0',
    fontSize: '32px',
    fontWeight: 'bold',
  },
  subtitle: {
    margin: '0',
    fontSize: '16px',
    opacity: 0.8,
  },
  statsContainer: {
    display: 'flex',
    justifyContent: 'center',
    padding: '20px',
    gap: '20px',
  },
  statCard: {
    backgroundColor: '#3498db',
    color: 'white',
    padding: '20px 40px',
    borderRadius: '8px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  },
  statValue: {
    fontSize: '28px',
    fontWeight: 'bold',
    marginBottom: '5px',
  },
  statLabel: {
    fontSize: '14px',
    opacity: 0.9,
  },
  cardsContainer: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(400px, 1fr))',
    padding: '20px',
    gap: '20px',
    maxWidth: '1400px',
    margin: '0 auto',
  },
  footer: {
    backgroundColor: '#34495e',
    color: '#bdc3c7',
    textAlign: 'center',
    padding: '20px',
    marginTop: '40px',
    fontSize: '14px',
  },
};

export default App;
