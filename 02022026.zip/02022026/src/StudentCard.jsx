import React from 'react';

const StudentCard = ({ name, rollNumber, marks }) => {
  // Calculate total marks
  const totalMarks = marks.reduce((sum, mark) => sum + mark, 0);
  
  // Calculate average
  const average = (totalMarks / marks.length).toFixed(2);
  
  // Determine grade based on average
  const getGrade = (avg) => {
    if (avg >= 90) return 'A';
    if (avg >= 80) return 'B';
    if (avg >= 70) return 'C';
    if (avg >= 60) return 'D';
    return 'F';
  };
  
  const grade = getGrade(average);
  
  // Determine grade color
  const getGradeColor = (gradeValue) => {
    switch(gradeValue) {
      case 'A': return '#27ae60'; // Green
      case 'B': return '#2980b9'; // Blue
      case 'C': return '#f39c12'; // Orange
      case 'D': return '#e67e22'; // Dark Orange
      case 'F': return '#e74c3c'; // Red
      default: return '#95a5a6';
    }
  };

  return (
    <div style={styles.card}>
      <div style={styles.header}>
        <h2 style={styles.name}>{name}</h2>
      </div>
      
      <div style={styles.body}>
        <div style={styles.infoRow}>
          <span style={styles.label}>Roll Number:</span>
          <span style={styles.value}>{rollNumber}</span>
        </div>
        
        <div style={styles.marksContainer}>
          <h3 style={styles.marksTitle}>Subject Marks:</h3>
          <div style={styles.marksList}>
            {marks.map((mark, index) => (
              <div key={index} style={styles.markItem}>
                <span style={styles.subject}>Subject {index + 1}:</span>
                <span style={styles.markValue}>{mark}/100</span>
              </div>
            ))}
          </div>
        </div>
        
        <div style={styles.resultContainer}>
          <div style={styles.resultItem}>
            <span style={styles.label}>Total Marks:</span>
            <span style={styles.resultValue}>{totalMarks}</span>
          </div>
          
          <div style={styles.resultItem}>
            <span style={styles.label}>Average:</span>
            <span style={styles.resultValue}>{average}%</span>
          </div>
          
          <div style={styles.resultItem}>
            <span style={styles.label}>Grade:</span>
            <span 
              style={{
                ...styles.grade,
                backgroundColor: getGradeColor(grade),
                color: 'white'
              }}
            >
              {grade}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  card: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    margin: '16px',
    maxWidth: '400px',
    overflow: 'hidden',
    fontFamily: 'Arial, sans-serif',
    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
    cursor: 'pointer',
  },
  header: {
    backgroundColor: '#3498db',
    color: 'white',
    padding: '20px',
    textAlign: 'center',
  },
  name: {
    margin: '0',
    fontSize: '24px',
    fontWeight: 'bold',
  },
  body: {
    padding: '20px',
  },
  infoRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '20px',
    paddingBottom: '10px',
    borderBottom: '1px solid #ecf0f1',
  },
  label: {
    fontWeight: 'bold',
    color: '#34495e',
  },
  value: {
    color: '#2c3e50',
  },
  marksContainer: {
    marginBottom: '20px',
  },
  marksTitle: {
    margin: '0 0 10px 0',
    fontSize: '16px',
    color: '#34495e',
  },
  marksList: {
    backgroundColor: '#f8f9fa',
    padding: '10px',
    borderRadius: '4px',
  },
  markItem: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '8px 0',
    borderBottom: '1px solid #e9ecef',
  },
  subject: {
    color: '#34495e',
  },
  markValue: {
    fontWeight: 'bold',
    color: '#2c3e50',
  },
  resultContainer: {
    backgroundColor: '#f0f4f8',
    padding: '15px',
    borderRadius: '4px',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
  },
  resultItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  resultValue: {
    fontWeight: 'bold',
    fontSize: '18px',
    color: '#2c3e50',
  },
  grade: {
    padding: '8px 16px',
    borderRadius: '4px',
    fontWeight: 'bold',
    fontSize: '16px',
  },
};

export default StudentCard;
